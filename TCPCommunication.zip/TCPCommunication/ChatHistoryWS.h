//
//  ChatHistoryWS.h
//  Forgeter
//
//  Created by Ravi Tailor on 21/11/14.
//  Copyright (c) 2014 Ravi Taylor. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TCPCommunication.h"
@protocol ChatHistoryWSDelegate <NSObject>
-(void)chatHistoryListSuccess:(NSDictionary *)dictHistory;
-(void)chatHistoryListFail;
@end

@interface ChatHistoryWS : NSObject<TCPDelegate>
@property (nonatomic,strong) TCPCommunication           *communication;
@property (nonatomic,strong) NSMutableArray             *arrListOfLastChatUser;
@property (nonatomic,weak)   id<ChatHistoryWSDelegate>      delegate;

-(void)chatHistoryListingPage:(NSString *)pageNo withUser:(NSString *)withUser;
@end
