//
//  ChatHistoryWS.m
//  Forgeter
//
//  Created by Ravi Tailor on 21/11/14.
//  Copyright (c) 2014 Ravi Taylor. All rights reserved.
//

#import "ChatHistoryWS.h"

@implementation ChatHistoryWS
-(id)init{
    self = [super init];
    if (self) {
        self.communication = [[TCPCommunication alloc] initWithBackgroundQueue:dispatch_queue_create("com.lagisatu.backgroundThread.ChatHistoryWS", NULL)];
        _communication.delegate = self;
        [_communication setUpCommunicationStream];
    }
    return self;
}

-(void)dealloc{
    [self.communication releaseData];
    [self.communication closeStream];
    self.communication = nil;
}
-(void)chatHistoryListingPage:(NSString *)pageNo withUser:(NSString *)withUser
{
    //JSon Dictionary
    
    NSMutableDictionary *dictJson = [[NSMutableDictionary alloc] init];
    [dictJson setObject:@"get_chat_history" forKey:@"request_action"];
    
    [dictJson setObject:[[CommonFuntions initializeUserDefaults] objectForKey:@"Token"] forKey:@"token"];
    [dictJson setObject:withUser forKey:@"with_user"];
    if([self isNotNull:pageNo])
        [dictJson setObject:pageNo forKey:@"page"];
    //Converting JSon Data into NSData
    NSError *error;
    NSData *requestData = [NSJSONSerialization dataWithJSONObject:dictJson options:NSJSONWritingPrettyPrinted error:&error];
    
    NSString *jsonRequest = [[NSString alloc] initWithData:requestData encoding:NSUTF8StringEncoding];
    
    //Sending Request
    [self.communication setUpCommunicationStream];
    [self.communication sendRequest:jsonRequest];
}


-(void)dataReceived:(NSData *)response{
    
    NSError *error;
    NSMutableDictionary *dictResponse = [NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:&error];
    if([self isNotNull:[dictResponse objectForKey:@"status"]])
    {
        if([[dictResponse objectForKey:@"status"] intValue] == 200)
        {
            if([self isNotNull:dictResponse])
            {
                if ([_delegate conformsToProtocol:@protocol(ChatHistoryWSDelegate)] &&
                    [_delegate respondsToSelector:@selector(chatHistoryListSuccess:)]){
                    [_delegate chatHistoryListSuccess:dictResponse];
                }
            }
        }else{
            if ([_delegate conformsToProtocol:@protocol(ChatHistoryWSDelegate)] &&
                [_delegate respondsToSelector:@selector(chatHistoryListFail)]){
                [_delegate chatHistoryListFail];
            }
        }
    }
    
}


@end
